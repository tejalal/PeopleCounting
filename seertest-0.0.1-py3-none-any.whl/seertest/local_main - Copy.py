import os
import pathlib
import time
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs
import databricks.sdk.service.compute as compute
from databricks.sdk.service.compute import AwsAttributes, LibrariesAPI
import argparse

from databricks_cli.sdk.api_client import ApiClient
from databricks_cli.sdk.api_client import ApiClient

from dbsdk import create_cluster, create_new_job, install_pylibraries

# from databricks_cli.sdk.libraries.api import LibrariesApi

# create cluster and run job
    #python local_main.py --cluster mycluster1 --wtype i3.xlarge --dtype i3.xlarge --nworkers 1 --terminate 20 --notebook job_demo --job myjob1 --dbhost https://dbc-dbb0572b-de4d.cloud.databricks.com/?o=570361873323899# --dbtoken dapi1735506746e7ed9391e0695daac9aef4 --iprofile arn:aws:iam::401440431258:instance-profile/seer-aws-databricks-workspace-stack-access-data-buckets --createcluster

# run job with the existing cluster
    #python local_main.py --notebook job_demo --job myjob1 --dbhost https://dbc-dbb0572b-de4d.cloud.databricks.com/?o=570361873323899# --dbtoken dapi1735506746e7ed9391e0695daac9aef4 --iprofile arn:aws:iam::401440431258:instance-profile/seer-aws-databricks-workspace-stack-access-data-buckets --clusterid 0719-151507-qndzjj2r
  
def main():
  # cluster and job settings
  parser = argparse.ArgumentParser(description='Distributed Proteomics Analysis')
  parser.add_argument('--cluster', type=str, default='mycluster1', help='cluster name (default: mycluster1)')
  parser.add_argument('--createcluster', action='store_true', default=False, help='create cluster (default: false)')
  parser.add_argument('--clusterid', type=str, default='', help='cluster id if the cluster is already created')
  parser.add_argument('--wtype', type=str, default='i3.2xlarge', help='worker type (default: i3.2xlarge)')
  parser.add_argument('--dtype', type=str, default='i3.2xlarge', help='driver-type (default: i3.2xlarge)')
  parser.add_argument('--nworkers', type=int, default=1, metavar='N', help='number of workers (default: 1)')
  parser.add_argument('--terminate', default=30, type=int, metavar='N', help='auto terminate the cluster if idele for specified minutes (default: 1)')
  parser.add_argument('--notebook', type=str, default='job_demo', help='notebook name to run (default: job_demo)')
  parser.add_argument('--job', type=str, default='my_job1', help='name of the job (default: my_job1)')
  parser.add_argument('--iprofile', type=str, default='seer-aws-databricks-workspace-stack-access-data-buckets', help='AWS instance profile')
  parser.add_argument('--dbhost', type=str, default='https://dbc-dbb0572b-de4d.cloud.databricks.com/?o=570361873323899#', help='Databricks host URL')
  parser.add_argument('--dbtoken', type=str, default='dapi9c89afcf5a2ee1f754dbbc47946c20a3', help='Databricks token')
  args = parser.parse_args()

  os.environ["DATABRICKS_HOST"] = args.dbhost #"https://dbc-dbb0572b-de4d.cloud.databricks.com/?o=570361873323899#"
  os.environ["DATABRICKS_TOKEN"] = args.dbtoken #"dapi4057350cfe3c9879d01749ccd4a62950"

  spark_conf = {
        "spark.rpc.message.maxSize": 1024,
        "spark.driver.maxResultSize": "0g"
    }

  #files/#cores = #nworkers
  workspace_client = WorkspaceClient()
  aws_attributes = AwsAttributes(
    instance_profile_arn =  args.iprofile
  )

  #create a cluster and run a job
  if args.createcluster:
    print(f'Creating new cluster.....')
    print(f'Cluster name: {args.cluster}')
    print(f'Worker type: {args.wtype}')
    print(f'Number of workers: {args.nworkers}')
    print(f'Driver type: {args.dtype}')
    print(f'Auto terminate cluster in {args.terminate } minutes')

    cluster_id = create_cluster(
              workspace_client=workspace_client,
              cluster_name=args.cluster,
              driver_type=args.dtype,
              worker_type=args.wtype,
              spark_conf=spark_conf,
              num_workers=args.nworkers,
              autotermination_minutes=args.terminate,
              aws_attributes=aws_attributes
              )

    # _ = workspace_client.clusters.start(start=cluster_id).result()
    print(f'Cluster is up and running, cluster id: {cluster_id}')
    print('installing libraries.....')
    install_pylibraries(workspace_client, cluster_id)
    
    # execute job on the created cluster
    print(f'Executing job with the started cluster')
    print(f'Notebook name: {args.notebook}')
    print(f'Job name: {args.job}')
    print(f'Cluster id: {cluster_id}')
    create_new_job(
              workspace_client=workspace_client,
              cluster_id=cluster_id,
              notebook_name=args.notebook,
              job_name=args.job
              )    

  # run job with existing cluster
  if not args.createcluster:
    cluster_id = args.clusterid
    print(f'Executing job with the previously created cluster, cluster_Id: {cluster_id}')
    # install_pylibraries(workspace_client, cluster_id)
    

    all = workspace_client.global_init_scripts.list()

    print(all)

    # create_new_job(
    #           workspace_client = workspace_client, 
    #           cluster_id = cluster_id, 
    #           notebook_name = args.notebook, 
    #           job_name = args.job
    #           )    

if __name__=="__main__":
  main()