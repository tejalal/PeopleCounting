import os
import pathlib
import time
import argparse
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs
import databricks.sdk.service.compute as compute
from databricks.sdk.service.compute import AwsAttributes, LibrariesAPI
import argparse
import datetime
from datetime import datetime


def create_cluster(workspace_client, cluster_name, driver_type, worker_type, spark_conf, aws_attributes, num_workers = 1, autotermination_minutes = 15):
  '''
  A function to create a new cluster
  '''
  
  cluster_name = cluster_name
  w = workspace_client
  # latest = w.clusters.select_spark_version(latest=True)
  clstr = w.clusters.create(cluster_name=f'{cluster_name}',
                            spark_version='12.2.x-scala2.12',
                            # instance_pool_id=os.environ["TEST_INSTANCE_POOL_ID"],
                            driver_node_type_id=driver_type,
                            node_type_id=worker_type,
                            autotermination_minutes=autotermination_minutes,
                            num_workers=1,
                            aws_attributes=aws_attributes
                            ).result()
  # cleanup
  # w.clusters.permanent_delete(permanent_delete=clstr.cluster_id)
  return clstr.cluster_id

def install_pylibraries(workspace_client, cluster_id):
  workspace_client.libraries.install(cluster_id=cluster_id,
                   libraries=[
                              compute.Library(pypi=compute.PythonPyPiLibrary(package="wget")), 
                              compute.Library(pypi=compute.PythonPyPiLibrary(package="tabulate")),
                              compute.Library(pypi=compute.PythonPyPiLibrary(package="matplotlib_venn")),
                              compute.Library(pypi=compute.PythonPyPiLibrary(package="alphapept")), 
                   ])

def create_new_job(workspace_client, cluster_id, notebook_name, job_name = 'test_job'):
  '''
  A function to create a new job
  '''
  
  w = workspace_client
  notebook_path = f'/Users/{w.current_user.me().user_name}/{notebook_name}'
  # cluster_id = w.clusters.ensure_cluster_is_running(
  #     os.environ["DATABRICKS_CLUSTER_ID"]) and os.environ["DATABRICKS_CLUSTER_ID"]

  created_job = w.jobs.create(name = f"{job_name}", #{time.time_ns()}', # f'temp_job-{time.time_ns()}'
                              tasks=[
                                  jobs.Task(description="a test job",
                                            existing_cluster_id=cluster_id,
                                            notebook_task=jobs.NotebookTask(notebook_path=notebook_path),
                                            task_key="test",
                                            timeout_seconds=0)
                              ])

  run_by_id = w.jobs.run_now(job_id=created_job.job_id).result()
  # print(f'job details: {run_by_id}')
  # cleanup
  # w.jobs.delete(delete=created_job.job_id)

#---------
def get_cluster_env(args, spark_conf):

  os.environ["DATABRICKS_HOST"] = args.dbhost
  os.environ["DATABRICKS_TOKEN"] = args.dbtoken

  workspace_client = WorkspaceClient()
  aws_attributes = AwsAttributes(
    instance_profile_arn =  args.iprofile
  )

  user = workspace_client.current_user.me().user_name.split('@')[0].replace('.', '_')

  if args.createcluster: # create a cluster and run a job
    cluster_name = f"{args.cluster}_{user}_{datetime.now().strftime('%b_%d_%Y')}"
    print('-----------------------')
    print(f'Creating new cluster.....')
    print(f'Cluster name: {cluster_name}')
    print(f'Worker type: {args.wtype}')
    print(f'Number of workers: {args.nworkers}')
    print(f'Driver type: {args.dtype}')
    print(f'Auto terminate cluster in {args.terminate } minutes')
    print(f'Cluster creation in progress.....')
    cluster_id = create_cluster(
              workspace_client=workspace_client,
              cluster_name=cluster_name,
              driver_type=args.dtype,
              worker_type=args.wtype,
              spark_conf=spark_conf,
              num_workers=args.nworkers,
              autotermination_minutes=args.terminate,
              aws_attributes=aws_attributes
              )

    job_name = f"{args.job}_{datetime.now().strftime('%b_%d_%Y_%X')}" 
    print(f'Cluster is up and running, cluster id: {cluster_id}')
    print('installing libraries.....')
    install_pylibraries(workspace_client, cluster_id)
    
    # execute job on the created cluster
    print(f'Executing job with the started cluster')
    print(f'Notebook name: {args.notebook}')
    print(f'Job name: {job_name}')
    print(f'Cluster id: {cluster_id}')
    create_new_job(
              workspace_client=workspace_client,
              cluster_id=cluster_id,
              notebook_name=args.notebook,
              job_name=job_name
              )    

  if not args.createcluster: ## run job with existing cluster
    cluster_id = args.clusterid
    job_name = f"{args.job}_{datetime.now().strftime('%b_%d_%Y_%X')}"
    print('-----------------------')
    print(f'Executing job with the existing cluster...')
    print(f'Cluster id: {cluster_id}')
    print(f'Notebook name: {args.notebook}')
    print(f'Job name: {job_name}')
    
    # install_pylibraries(workspace_client, cluster_id)
    
    create_new_job(
              workspace_client = workspace_client, 
              cluster_id = cluster_id, 
              notebook_name = args.notebook, 
              job_name = job_name
              )
  print(f'Execution completed.')