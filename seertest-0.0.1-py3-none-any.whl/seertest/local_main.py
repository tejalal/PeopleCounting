import os
import pathlib
import time
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs
import databricks.sdk.service.compute as compute
from databricks.sdk.service.compute import AwsAttributes, LibrariesAPI
import argparse

from dbsdk import create_cluster, create_new_job, install_pylibraries

def get_cluster_env(args):

  os.environ["DATABRICKS_HOST"] = args.dbhost
  os.environ["DATABRICKS_TOKEN"] = args.dbtoken

  spark_conf = {
        "spark.rpc.message.maxSize": 1024,
        "spark.driver.maxResultSize": "0g"
    }

  workspace_client = WorkspaceClient()
  aws_attributes = AwsAttributes(
    instance_profile_arn =  args.iprofile
  )

  if args.createcluster: # create a cluster and run a job
    cluster_id = create_cluster(
              workspace_client=workspace_client,
              cluster_name=args.cluster,
              driver_type=args.dtype,
              worker_type=args.wtype,
              spark_conf=spark_conf,
              num_workers=args.nworkers,
              autotermination_minutes=args.terminate,
              aws_attributes=aws_attributes
              )

    install_pylibraries(workspace_client, cluster_id)
    
    # execute job on the created cluster
    create_new_job(
              workspace_client=workspace_client,
              cluster_id=cluster_id,
              notebook_name=args.notebook,
              job_name=args.job
              )    

  if not args.createcluster: ## run job with existing cluster
    cluster_id = args.clusterid
    print(f'Executing job with the existing cluster, cluster_Id: {cluster_id}')

    # install_pylibraries(workspace_client, cluster_id)
    
    create_new_job(
              workspace_client = workspace_client, 
              cluster_id = cluster_id, 
              notebook_name = args.notebook, 
              job_name = args.job
              )